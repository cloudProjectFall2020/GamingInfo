# GamingInfo
project to create a website that can store gaming information for a user and view it using cloud services
