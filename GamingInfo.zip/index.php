<?php 
    include_once 'header.php';
?>
        <section class="indexIntro">
            
        <article class="information">
            <h1>Welcome to Gaming Room</h1>
            <img class="image-gaming" src="image/controller.png" alt= "controller">

        <h1>This is an intro</h1>
        <p>Some random paragraph</p>
        </article>
   
        <h2>Some stuff</h2>

        <h3>Some more stuff</h3>
    </section>
  
<?php 
    include_once 'footer.php';
?>