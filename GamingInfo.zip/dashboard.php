<?php

    include_once 'header.php';

?>

    <div class="Temp">
        <h1>Under Construction</h1>
    </div>

<?php

include_once 'footer.php';

?>